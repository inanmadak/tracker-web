

export const trackListSelector = state => state.trackList

export const searchTextSelector = state => state.searchText